#This is my first Python program

print("Hello World!")

num1 = input("Enter First number: ")
num2 = input("Enter second number: ")
sum = float(num1) + float(num2)

print(sum)
