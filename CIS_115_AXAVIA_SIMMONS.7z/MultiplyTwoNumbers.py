#This is my program to multiply two numbers

num1 = 70
num2 = 11
unit= "mph"

result = num1 * num2

print(f'My result value is: {result} {unit}')