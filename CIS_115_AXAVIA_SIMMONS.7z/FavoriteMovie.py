# This program shows my favorite movie with the main characters

favorite_movie = "The Lion King"

main_characters = ("""
                   Mufasa
                   Scar
                   Timone
                   Pumba
                   Nala
                   Rafiki
                   Shenzi
                   Kamari
                   Azizi""")


print(f'My favorite movie is: {favorite_movie}')
print(f'The main characters are: {main_characters}')