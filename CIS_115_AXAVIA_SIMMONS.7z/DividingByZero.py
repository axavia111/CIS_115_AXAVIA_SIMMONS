# This is my program dividing by 0

numerator = 10
denominator = 0
result = numerator / denominator
print(result)