#This is my program to square root a real number

num1 = 64
num2 = 0.5
result = num1 ** num2

print(f'The Square Root is: {result}')